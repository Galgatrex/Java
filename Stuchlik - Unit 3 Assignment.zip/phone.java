import java.util.Scanner; // Needed for the Scanner class
import javax.swing.JOptionPane; // Needed for JOptionPane
import java.io.*; // Required for I/O 
import javax.swing.*; 
import javax.swing.event.*; 
import java.awt.*; 
import java.awt.event.*;
import java.text.DecimalFormat;
import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;

/* 
Author: Jacob Stuchlik
Date: 29 Jan 2017

Write an application that displays a menu system. 
The menu system should allow the user to select one package, 
one phone, and any of the options desired. As the user selects 
items from the menu, the application should show the prices of 
the items selected.
*/

public class phone extends JFrame
{
	private JLabel messageLabel;
	private final int LABEL_WIDTH = 100; // Set label width 
	private final int LABEL_HEIGHT = 100; // Set label height
	
	// Declare variables for building the menu system
	private JMenuBar menuBar; 
	private JMenu fileMenu; 
	private JMenu packageMenu; 
	private JMenu phoneMenu;
	private JMenuItem exitItem;
	private JRadioButtonMenuItem package300; 
	private JRadioButtonMenuItem package800; 
	private JRadioButtonMenuItem package1500; 
	private JRadioButtonMenuItem model100;
	private JRadioButtonMenuItem model110;
	private JRadioButtonMenuItem model200;
	private JCheckBoxMenuItem voiceMail;
	private JCheckBoxMenuItem textMessage;
	
	// Create GUI items for main display
	private JTextField displayTotal;
	private JLabel label1;
	private JPanel xpanel;
	private JPanel cpanel;
	private JButton calcButton; // Calculates purchase total
	
	// Constructor for creating the menu system 
	public phone()
	{	
		// Title
		setTitle("Menu System");
		
		// Specify close button
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Message Label for title label
		messageLabel = new JLabel();
		
		// Set size
		messageLabel.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
		
		// Set foreground color
		messageLabel.setForeground(Color.BLACK);
		
		// Add label to content pane
		add(messageLabel);
		
		// Build menu bar
		buildMenuBar();
		
		// Create the message label for total box
		label1 = new JLabel("Total: ");
		
		
		
		// Create panels and place the components in them
		xpanel = new JPanel();
		xpanel.add(label1);
		
		
		
		// Create read-only fields
		displayTotal = new JTextField("0.0", 10);
		displayTotal.setEditable(false);
		xpanel.add(displayTotal);
		
		// Create a GridLayout manager
		setLayout(new GridLayout(3, 1));
		
		// Add panels to content pane
		add(xpanel);
		
		// Add button 
		calcButton = new JButton("Calculate");
		xpanel.add(calcButton);
		calcButton.addActionListener(new buttonListener());
		
		// Pack and display window
		pack();
		setVisible(true);
	}
	
	// buildMenuBar builds menu bar
	private void buildMenuBar()
	{		
		// Create menu bar
		menuBar = new JMenuBar();
		
		// Create file and text menus
		buildFileMenu();
		buildPackageMenu();
		buildPhoneMenu();
		
		// Add menus to menu bar
		menuBar.add(fileMenu);
		menuBar.add(packageMenu);
		menuBar.add(phoneMenu);
		
		// Set window's menu bar
		setJMenuBar(menuBar);
	}
	
	// buildFileMenu method builds file menu and returns a reference to JMenu 
	private void buildFileMenu()
	{
		// Create an exit menu item
		exitItem = new JMenuItem("Exit");
		exitItem.setMnemonic(KeyEvent.VK_X);
		exitItem.addActionListener(new ExitListener());
		
		// Create a JMenu object for file menu 
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		
		// Add the Exit menu item to the File menu
		fileMenu.add(exitItem);
	}
	
	// Build package menu items
	public void buildPackageMenu() 
	{
		// Create package radio button menu items and mnemonics for each
		package300 = new JRadioButtonMenuItem("300 Minute Package ($45)", true);
		package300.setMnemonic(KeyEvent.VK_B);
		
		package800 = new JRadioButtonMenuItem("800 Minute Package ($65)");
		package800.setMnemonic(KeyEvent.VK_R);
		
		package1500 = new JRadioButtonMenuItem("1500 Minute Package ($99)");
		package1500.setMnemonic(KeyEvent.VK_U);
		
		// Create button group for package radio buttons
		ButtonGroup group = new ButtonGroup();
		group.add(package300);
		group.add(package800);
		group.add(package1500);
		
		// Create JMenu object for text menu
		packageMenu = new JMenu("Package Menu"); 
		packageMenu.setMnemonic(KeyEvent.VK_T); // Set mnemonic for package menu
		voiceMail = new JCheckBoxMenuItem("Voice Mail ($5)"); // Create check box
		textMessage = new JCheckBoxMenuItem("Text Message ($10)"); // Create check box
		
		// Add menu items to text menu 
		packageMenu.add(package300); // 300 minute package
		packageMenu.add(package800); // 800 minute package
		packageMenu.add(package1500); // 1500 minute package
		packageMenu.addSeparator(); // Separator bar 
		packageMenu.add(voiceMail); // Voice Mail check box option
		packageMenu.add(textMessage); // Text message check box option
		
	}
	
	// Create phone menu
	public void buildPhoneMenu()
	{
		// Create JMenu object for text menu
		phoneMenu = new JMenu("Phone Menu");
		
		// Create phone radio button menu to select one for purchase
		model100 = new JRadioButtonMenuItem("Model 100 ($29.95)");
		model110 = new JRadioButtonMenuItem("Model 110 ($49.95)");		
		model200 = new JRadioButtonMenuItem("Model 1200 ($99.95)");
		
		// Create button group for radio buttons
		ButtonGroup group2 = new ButtonGroup();
		group2.add(model100);
		group2.add(model110);
		group2.add(model200);
		
		// Add menu items to text menu 
		phoneMenu.add(model100);
		phoneMenu.add(model110);
		phoneMenu.add(model200);		
		
	}
	
	// Create button listener class for calculating total
	public class buttonListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e)
		{
			// Declares variables for calculating total
			double total = 0;
			double preTotal = 0;
			double packageTotal = 0;
			
			// Decimal Format for final output
			DecimalFormat dollar = new DecimalFormat("0.00");
			
	///////////////// Checks for Phone menu selection items
		
			if (model100.isSelected())
			{
				total = total + 29.95;
				displayTotal.setText(Double.toString(total));

			}
		
			else if (model110.isSelected())
			{					
				total = total + 49.95;
				displayTotal.setText(Double.toString(total));

			}
		
			else if (model200.isSelected())
			{				
				total = total + 99.95;
				displayTotal.setText(Double.toString(total));

			}
		
			else 
			{
				displayTotal.setText("Invalid Selection");
			}
		
			// Calculates total of phone selection items
			preTotal = total * .06;
			total = preTotal + total;		
		
		////////////////////////////////////////////
		
		// Checks for Package Menu Selection Items //////////////////////
		
			if (package300.isSelected())
			{
				packageTotal = packageTotal + 45.0;
			}
			
			else if (package800.isSelected())
			{
				packageTotal = packageTotal + 65.0;
			}
			
			else if (package1500.isSelected())
			{
				packageTotal = packageTotal + 99.0;
			}
			
			// Checks for check in Voice Mail check box
			if (voiceMail.isSelected())
			{
				packageTotal = packageTotal + 5.0;
			}
			
			// Checks for check in Text Message check box
			if (textMessage.isSelected())
			{
				packageTotal = packageTotal + 10.0;
			}
					
			// Calculates total of all selected items
			total = packageTotal + total;	
									
			/////////////////////////////////////////////////
			
			// Displays total calculated by all selection items
			displayTotal.setText(dollar.format(total));

		}
	}

	
	// Private inner class that handles exit event 
	private class ExitListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			System.exit(0);
		}
	}

	
	// Main method - creates instance of Menu Window 
	public static void main(String[] args)
	{		
		phone ph = new phone();
	}
}
			
	
	
	
	
	
	
	
	
	