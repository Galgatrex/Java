import java.util.Scanner; // Needed for the Scanner class
import javax.swing.JOptionPane; // Needed for JOptionPane
import java.io.*; // Required for I/O 
import javax.swing.*; 
import javax.swing.event.*; 
import java.awt.*; 
import java.text.DecimalFormat;

	/* 
	Create an application that allows you to enter the amount
	of a purchase and then displays the amount of sales tax on that 
	purchase. Use a slider to adjust the tax rate between 0 percent 
	and 10 percent.
	*/

public class tax extends JFrame
{
		// Declared private variables
		private JLabel label1, label2, label3;
		private JTextField textTitle, displayPrice, displayTotal;
		private JPanel xpanel, cpanel, tpanel;
		private JPanel sliderPanel;
		private JSlider slider;
		
	// Constructor 	
	public tax()
	{
		
		// Set title
		setTitle("Taxes");
		
		// Specify an action for the close button
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Create the message labels
		label1 = new JLabel("Tax Rate: ");
		label2 = new JLabel("Purchase price: ");
		label3 = new JLabel("Total: ");
		
		// Create read-only fields
		textTitle = new JTextField(".05", 10);
		textTitle.setEditable(false);
		displayPrice = new JTextField(10);
		displayTotal = new JTextField("0", 10);
		displayTotal.setEditable(false);
		
		// Create slider
		slider = new JSlider(JSlider.HORIZONTAL, 0, 10, 5);
		slider.setMajorTickSpacing(5);
		slider.setMinorTickSpacing(1);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.addChangeListener(new SliderListener());
		
		// Create panels and place the components in them
		xpanel = new JPanel();
		xpanel.add(label1);
		xpanel.add(textTitle);
		cpanel = new JPanel();
		cpanel.add(label2);
		cpanel.add(displayPrice);
		sliderPanel = new JPanel();
		sliderPanel.add(slider);
		tpanel = new JPanel();
		tpanel.add(label3);
		tpanel.add(displayTotal);
		
		// Create a GridLayout manager
		setLayout(new GridLayout(4, 1));
		
		// Add panels to content pane
		add(xpanel);
		add(cpanel);
		add(tpanel);
		add(sliderPanel);
		
		// Decimal Format
		DecimalFormat dollar = new DecimalFormat("#,##0.00");
		
		// Pack and display the frame
		pack();
		setVisible(true);
		
	}
	
	private class SliderListener implements ChangeListener
	{
		public void stateChanged(ChangeEvent e)
		{
			// Variables
			double taxes;
			double total;
			double taxRate;
			double preTotal;
			
			DecimalFormat fmt = new DecimalFormat("0.00");
		
			// Get the slider value
			taxes = slider.getValue();
			taxRate = taxes / 100;
				
			// Variables
			String input;
			double price;
			
			// Get input from purchase price box 
			input = displayPrice.getText();
			price = Double.parseDouble(input);
			
			// Calculating total price based off of purchase price and tax rate
			preTotal = taxRate * price;
			total = preTotal + price;
			
			// Shows tax rate based off of slider position
			textTitle.setText(Double.toString(taxRate));
			
			// Displays calculated total in total box 
			displayTotal.setText(Double.toString(total));
		}
	}

	// Creates instance of the class, which displays a window with a slider
	public static void main(String[] args)
	{		
		new tax();
	}
	

} 
		
		
	
	