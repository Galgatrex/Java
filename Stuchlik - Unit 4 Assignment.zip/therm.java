import java.util.Scanner; // Needed for the Scanner class
import javax.swing.JOptionPane; // Needed for JOptionPane
import java.io.*; // Required for I/O 
import javax.swing.*; 
import javax.swing.event.*; 
import java.awt.*; 
import java.awt.event.*;
import java.text.DecimalFormat;
import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;

/* 
Author: Jacob Stuchlik
Date: 31 Jan 2017

Write an applet that displays a thermometer. 
The user should be able to control the temperature with 
a slider component. When the user moves the slider, the 
thermometer should show the corresponding temperature.

*/


public class therm extends JApplet
{
	// Declared private variables
		private JLabel label1;
		private JTextField displayTemp;
		private JPanel tpanel;
		private JPanel sliderPanel;
		private JSlider slider;
		
	// Constructor 	
	public therm()
	{	
		// Create the message labels
		label1 = new JLabel("Temperature: ");
		
		// Create read-only fields
		displayTemp = new JTextField("0.0", 10);
		displayTemp.setEditable(false);
		
		// Create slider
		slider = new JSlider(JSlider.VERTICAL, 0, 100, 50);
		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(1);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.addChangeListener(new SliderListener());
		
		// Create panels and place the components in them
		sliderPanel = new JPanel();
		sliderPanel.add(slider);
		tpanel = new JPanel();
		tpanel.add(label1);
		tpanel.add(displayTemp);
		
		// Create a GridLayout manager
		setLayout(new FlowLayout());
		
		// Add panels to content pane
		add(tpanel);
		add(sliderPanel);
		
		// Decimal Format
		DecimalFormat temp = new DecimalFormat("0.00");
		
		// Pack and display the frame
		setVisible(true);
	}
	
	private class SliderListener implements ChangeListener
	{
		public void stateChanged(ChangeEvent e)
		{
			// Variables
			double temp;
			
			DecimalFormat fmt = new DecimalFormat("0.00");
		
			// Get the slider value
			temp = slider.getValue();
			
			// Displays calculated total in total box 
			displayTemp.setText(Double.toString(temp));
		}
	}
	
	// Creates instance of the class, which displays a window with a slider
	public static void main(String[] args)
	{		
		new therm();
	}
}	
	
	
	
	
	
	
	
	
	
	