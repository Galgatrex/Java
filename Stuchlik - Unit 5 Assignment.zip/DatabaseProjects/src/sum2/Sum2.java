/*

3. Unpaid Order Sum Write an application that connects to the 
CoffeeDB database, then calculates and displays the total amount 
owed in unpaid orders. This will be the sum of each row’s Cost 
column. 

*/

import java.util.Scanner; // Needed for the Scanner class
import javax.swing.JOptionPane; // Needed for JOptionPane
import java.io.*; // Required for I/O 
import javax.swing.*; 
import javax.swing.event.*; 
import java.awt.*; 
import java.awt.event.*;
import java.text.DecimalFormat;
import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.sql.*;


/* 
Author: Jacob Stuchlik
Date: 09 Feb 2017

*/


public class sum2
{
	public static void main(String[] args)
	{
		final String DB_URL = "jdbc:derby:CoffeeDB";
		
		try
		{
			// Register the Derby driver
			DriverManager.registerDriver(new org.apache.derby.jdbc.EmbeddedDriver());
			
			//Create connection
			Connection conn = DriverManager.getConnection(DB_URL);
			System.out.println("Connected to CoffeeDB.");
			
			// Create a statement object
			Statement stmt = conn.createStatement();
			
			//Create a string with a select statement
			String sqlStatement = "SELECT Cost FROM UnpaidOrder";
			
			//Send statemetn to DBMS
			ResultSet result = stmt.executeQuery(sqlStatement);
			
			//Display a header for the listing
			System.out.println("Unpaid Orders Results:");
			System.out.println("--------------------");
			
			double sum = 0;
                        double presum = 0;
                        String var = "x";
			
			//Display contents of result set
			while(result.next())
			{       
                                var = result.getString("Cost");
                                                                
                                presum = Double.parseDouble(var);
                                
                                System.out.println("Listing unapid balances... " + presum);
                                
                                sum = sum + presum;
                               
			}
                        
                        System.out.println("The total of the unpaid balances is: " + sum);
			
			// Close connection
			conn.close();
			System.out.println("Connection closed");
		}
		
		catch(Exception ex)
		{
			System.out.println("ERROR: " + ex.getMessage());
		}
	}
}
	
	
	
	
	
	
	