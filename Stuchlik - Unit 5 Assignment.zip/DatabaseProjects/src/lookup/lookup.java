/**************
 4. Unpaid Order Lookup Write an application that connects 
to the CoffeeDB database and displays a JList component. The JList 
component should display a list of customers with unpaid orders. 
When the user clicks on a customer, the application should display 
a summary of all the unpaid orders for that customer.
* 
* -- get unpaid orders based off of that customer number
* add while statement that gets customer number and just output 
* code to cmd line instead of 
* joption... might output several lines easier
****************/

import java.util.Scanner; // Needed for the Scanner class
import javax.swing.JOptionPane; // Needed for JOptionPane
import java.io.*; // Required for I/O 
import javax.swing.*; 
import javax.swing.event.*; 
import java.awt.*; 
import java.awt.event.*;
import java.text.DecimalFormat;
import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.sql.*;


/* 
Author: Jacob Stuchlik
Date: 09 Feb 2017

*/


public class lookup extends JFrame 
{
    
    
    private JList customerList; // A list for customer names
    private JPanel mainPanel;
    private JMenuItem exitItem;
    private JMenu fileMenu;
    private JMenuBar menuBar;
    private JLabel label;
    private JLabel displayMoney;
    private final int LABEL_WIDTH = 100;
    private final int LABEL_HEIGHT = 100;
    private JButton submitButton;
    
    // Constructor
    
    public lookup()
    {
        final String DB_URL = "jdbc:derby:CoffeeDB";

        try
        {
            
            // Create a connection to the database.
            Connection conn = DriverManager.getConnection(DB_URL);
                                    
            // Get a Statement object.
	    Statement stmt  = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                                                    ResultSet.CONCUR_READ_ONLY);
         
            ResultSet resultSet = stmt.executeQuery("SELECT Name FROM Customer");

////////////////////////////////////////////////////////////////////////////////
////////////// Get a list of customer names as a String array
            
            // Get number of rows
            resultSet.last();
            int numRows = resultSet.getRow();
            resultSet.first();
            
            // String array
            String[] names = new String[numRows];
            
            for (int index = 0; index < numRows; index++)
            {
                // Store customer names in array
                names[index] = resultSet.getString(1);
                
                // Go to next row
                resultSet.next();
            }
///////////////End Array////////////////////////////////////////////////////////   
            
            // Close the connection.
            conn.close();
            
            // Create panels
            mainPanel = new JPanel();
        
            // Title
            setTitle("Customer Lookup");
		
            // Specify close button
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
            // Create a GridLayout manager
            setLayout(new FlowLayout());
                        
             // Create a JList object to hold customer names
            customerList = new JList(names);
            
            // Set the number of visible rows
            customerList.setVisibleRowCount(numRows);
            
            // Put JList object in scroll pane
            JScrollPane scrollPane = new JScrollPane(customerList);

            // Add scroll pane to panel
            mainPanel.add(scrollPane);
            
            label = new JLabel("Select Customer");
            add(label);
            label.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
	    label.setForeground(Color.BLACK);
                        
            // Add panel to content pane
            add(mainPanel);
            
            // Add button
            submitButton = new JButton("Submit");
            mainPanel.add(submitButton);
            submitButton.addActionListener(new buttonListener());
            
            // Pack and display window
            pack();
            setVisible(true);
        }
        
        catch (SQLException ex)
        {
            ex.printStackTrace();
            System.exit(0);
        }
    }
    
    public class buttonListener implements ActionListener
    {
        public String getCustomer()
        {
            return (String) customerList.getSelectedValue();
        }
        
        public void actionPerformed(ActionEvent e)
        {
            String custName = getCustomer();
        
            final String DB_URL = "jdbc:derby:CoffeeDB";
        
        try
        {
            // Register the Derby driver
	    DriverManager.registerDriver(new org.apache.derby.jdbc.EmbeddedDriver());
                        
            // Create a connection to the database.
            Connection conn = DriverManager.getConnection(DB_URL);
            System.out.println("\n" + custName);
                                
            // Get a Statement object.
	    Statement stmt = conn.createStatement();
                        
            ResultSet resultSet = stmt.executeQuery("SELECT CustomerNumber FROM Customer WHERE Name = '" + custName + "'");
            resultSet.next();
            String custNum = resultSet.getString("CustomerNumber");
            System.out.println("Customer Number: " + custNum);

            ResultSet secondSet = stmt.executeQuery("SELECT ProdNum, OrderDate, Quantity, Cost FROM UnpaidOrder WHERE UnpaidOrder.CustomerNumber = '" + custNum + "'");
            while(secondSet.next())
            {
                System.out.println("\nOrder Summary: \n");
                System.out.println("Product Number: " + secondSet.getString("ProdNum"));
                                System.out.println("Date Ordered: " + secondSet.getString("OrderDate"));
                                                System.out.println("Quantity Ordered: " + secondSet.getString("Quantity"));
                                                                System.out.println("Cost of order: " + secondSet.getString("Cost"));
            }           

            // Close the connection.
            conn.close();
        }
            
        catch (Exception ex)
        {
            System.out.println("ERROR: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(0);
        }
        
    }
    }
    
    // Private inner class that handles exit event 
    private class ExitListener implements ActionListener
    {
        private void buildMenuBar()
        {
             // Create menu
             menuBar = new JMenuBar();
        
             // Create file menu
             buildFileMenu();
        
             // Menu
             menuBar.add(fileMenu);
        }
        
        // builds file menu and returns a reference to JMenu 
	public void buildFileMenu()
	{
		// Create an exit menu item
		exitItem = new JMenuItem("Exit");
		exitItem.setMnemonic(KeyEvent.VK_X);
		exitItem.addActionListener(new ExitListener());
		
		// Create a JMenu object for file menu 
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		
		// Add the Exit menu item to the File menu
		fileMenu.add(exitItem);
	}
        
        public void actionPerformed(ActionEvent e)
	{
		System.exit(0);
	}
    }
    
    public static void main(String[] args)
    {   
        lookup cuspan = new lookup();
    }
}
	
	
	
	
	